# chartokenizer/__init__.py
from .tokenizer import Tokenizer